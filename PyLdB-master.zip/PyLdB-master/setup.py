"""pyldb: A tool for the calculation of the perceived loudness of a pressure signature."""

from setuptools import setup

setup(name='pyldb',
      version='0.0',
      description='A tool for the calculation of the perceived loudness of a pressure signature.',
      url='NA',
      author='usuaero',
      author_email='doug.hunsaker@usu.edu',
      license='MIT',
      py_module=['pyldb'],
      zip_safe=False)
